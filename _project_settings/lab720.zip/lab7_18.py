from math import sqrt, sin


def app():
    n = int(input())
    result = sqrt(21 + sqrt(3 ** n) / (3 / sin(n)))
    print(result)


if __name__ == "__main__":
    app()
