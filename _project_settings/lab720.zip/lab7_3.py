def app():
    val1 = float(input())
    val2 = float(input())
    result = val1 ** val2
    print(result)


if __name__ == "__main__":
    app()