def app():
    val1 = 10
    val2 = int(input())
    result = val1 * val2
    print(result)


if __name__ == "__main__":
    app()
