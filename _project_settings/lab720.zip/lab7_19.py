def app():
    n = int(input())
    result = (2 * n ** 2 - 4 * n + 10) / (2 * n)
    print(result)


if __name__ == "__main__":
    app()
