def app():
    n = int(input())
    result = (n ** 2 + 5) * 16 / (25 / (3 * n))
    print(result)


if __name__ == "__main__":
    app()
