def app():
    my_list = list(map(int, input().strip().split()))
    result = my_list[1] * my_list[len(my_list) // 2]
    print(result)


if __name__ == "__main__":
    app()
