from math import sqrt, tan


def app():
    n = int(input())
    result = (tan(n) - 2 * n) / sqrt(10 + 0.6 * n)
    print(result)


if __name__ == "__main__":
    app()
