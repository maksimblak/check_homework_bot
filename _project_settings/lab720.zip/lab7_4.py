def app():
    val1 = float(input())
    val2 = float(input())
    result = (val1 * 3 + val1) / 4 - val2
    print(result)


if __name__ == "__main__":
    app()