from math import sqrt, sin


def app():
    n = int(input())
    result = (3 * sin(n) - 15) / sqrt(n ** 5)
    print(result)


if __name__ == "__main__":
    app()
