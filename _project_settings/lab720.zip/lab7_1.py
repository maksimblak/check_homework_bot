def app():
    val1 = int(input())
    val2 = int(input())
    val3 = int(input())

    print(val1+ val2+val3)


if __name__ == "__main__":
    app()
 