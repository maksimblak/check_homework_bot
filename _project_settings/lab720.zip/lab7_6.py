def app(val1: int):
    result = val1 % 3
    print(result)


if __name__ == "__main__":
    val1 = 157
    app(val1)