from math import sqrt


def app():
    n = int(input())
    result = (sqrt(n + 5) + (n ** 2 + 1) / 3) / (2 * n)
    print(result)


if __name__ == "__main__":
    app()
