def app(val1: int):
    result = val1 // 4
    print(result)


if __name__ == "__main__":
    val1 = 254
    app(val1)
