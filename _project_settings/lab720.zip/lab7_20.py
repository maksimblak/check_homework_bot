from math import sqrt


def app():
    n = int(input())
    result = ((sqrt(n ** 3 - n)) / n)
    print(result)


if __name__ == "__main__":
    app()
