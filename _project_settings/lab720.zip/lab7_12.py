from math import sqrt


def app():
    n = int(input())
    result = (n - 20) / sqrt(n)
    print(result)


if __name__ == "__main__":
    app()
