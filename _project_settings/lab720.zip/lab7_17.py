from math import sqrt, cos


def app():
    n = int(input())
    result = (10 + 2 * cos(n)) / (5 - sqrt(n ** 5))
    print(result)


if __name__ == "__main__":
    app()
