from math import sqrt, cos


def app():
    n = int(input())
    result = (5 * n * cos(n)) / sqrt(n ** 3)
    print(result)


if __name__ == "__main__":
    app()
