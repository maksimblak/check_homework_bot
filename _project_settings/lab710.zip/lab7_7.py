def app():
    val1 = float(input())
    val2 = float(input())
    val3 = float(input())

    result = (val1 + val2) / (val2 - val3)
    print(result)


if __name__ == "__main__":
    app()
